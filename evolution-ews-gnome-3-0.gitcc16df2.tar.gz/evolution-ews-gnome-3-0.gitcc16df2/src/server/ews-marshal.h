
#ifndef __ews_marshal_MARSHAL_H__
#define __ews_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

/* NONE:OBJECT,OBJECT,BOOLEAN (./ews-marshal.list:1) */
extern void ews_marshal_VOID__OBJECT_OBJECT_BOOLEAN (GClosure     *closure,
                                                     GValue       *return_value,
                                                     guint         n_param_values,
                                                     const GValue *param_values,
                                                     gpointer      invocation_hint,
                                                     gpointer      marshal_data);
#define ews_marshal_NONE__OBJECT_OBJECT_BOOLEAN	ews_marshal_VOID__OBJECT_OBJECT_BOOLEAN

G_END_DECLS

#endif /* __ews_marshal_MARSHAL_H__ */

