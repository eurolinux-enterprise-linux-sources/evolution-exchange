/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
/*
 * Authors :
 *
 * Copyright (C) 1999-2008 Novell, Inc. (www.novell.com)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of version 2 of the GNU Lesser General Public
 * License as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301
 * USA
 */

#ifndef E_EWS_ITEM_H
#define E_EWS_ITEM_H

#include "e-soap-message.h"
#include "e-soap-response.h"

G_BEGIN_DECLS

#define E_TYPE_EWS_ITEM            (e_ews_item_get_type ())
#define E_EWS_ITEM(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), E_TYPE_EWS_ITEM, EEwsItem))
#define E_EWS_ITEM_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), E_TYPE_EWS_ITEM, EEwsItemClass))
#define E_IS_EWS_ITEM(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), E_TYPE_EWS_ITEM))
#define E_IS_EWS_ITEM_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), E_TYPE_EWS_ITEM))

typedef struct _EEwsItem        EEwsItem;
typedef struct _EEwsItemClass   EEwsItemClass;
typedef struct _EEwsItemPrivate EEwsItemPrivate;

typedef enum {
	E_EWS_ITEM_TYPE_UNKNOWN,
	E_EWS_ITEM_TYPE_MESSAGE,
	E_EWS_ITEM_TYPE_POST_ITEM,
	E_EWS_ITEM_TYPE_CALENDAR_ITEM,
	E_EWS_ITEM_TYPE_CONTACT,
	E_EWS_ITEM_TYPE_GROUP,
	E_EWS_ITEM_TYPE_MEETING_MESSAGE,
	E_EWS_ITEM_TYPE_MEETING_REQUEST,
	E_EWS_ITEM_TYPE_MEETING_RESPONSE,
	E_EWS_ITEM_TYPE_MEETING_CANCELLATION,
	E_EWS_ITEM_TYPE_TASK,
	E_EWS_ITEM_TYPE_GENERIC_ITEM
} EEwsItemType;

typedef enum {
	EWS_ITEM_LOW,
	EWS_ITEM_NORMAL,
	EWS_ITEM_HIGH
} EwsImportance;

struct _EEwsItem {
	GObject parent;
	EEwsItemPrivate *priv;
};

struct _EEwsItemClass {
	GObjectClass parent_class;
};

typedef struct {
	gchar *id;
	gchar *change_key;
} EwsId;

typedef struct {
	gchar *name;
	gchar *email;
	gchar *mb_type;
	EwsId *item_id;
} EwsMailbox;

typedef struct {
	EwsMailbox *mailbox;
	gchar *attendeetype;
	gchar *responsetype;
} EwsAttendee;

typedef struct {
	gchar *title;
	gchar *first_name;
	gchar *middle_name;
	gchar *last_name;
	gchar *suffix;
	gchar *initials;
	gchar *full_name;
	gchar *nick_name;
	gchar *yomi_first_name;
	gchar *yomi_last_name;
} EwsCompleteName;

typedef struct {
	gchar *street;
	gchar *city;
	gchar *state;
	gchar *country;
	gchar *postal_code;
} EwsAddress;

GType       	e_ews_item_get_type (void);
EEwsItem *	e_ews_item_new_from_soap_parameter
						(ESoapParameter *param);

EEwsItemType 	e_ews_item_get_item_type	(EEwsItem *item);
void		e_ews_item_set_item_type	(EEwsItem *item,
						 EEwsItemType new_type);
const gchar *	e_ews_item_get_subject		(EEwsItem *item);
void		e_ews_item_set_subject		(EEwsItem *item,
						 const gchar *new_subject);
const gchar *	e_ews_item_get_mime_content	(EEwsItem *item);
void		e_ews_item_set_mime_content	(EEwsItem *item,
						 const gchar *new_mime_content);
const EwsId *	e_ews_item_get_id		(EEwsItem *item);
const EwsId *	e_ews_item_get_attachment_id		(EEwsItem *item);
gsize		e_ews_item_get_size		(EEwsItem *item);
const gchar *	e_ews_item_get_msg_id		(EEwsItem *item);
const gchar *	e_ews_item_get_uid		(EEwsItem *item);
const gchar *	e_ews_item_get_in_replyto	(EEwsItem *item);
const gchar *	e_ews_item_get_references	(EEwsItem *item);
time_t		e_ews_item_get_date_received	(EEwsItem *item);
time_t		e_ews_item_get_date_sent	(EEwsItem *item);
time_t		e_ews_item_get_date_created	(EEwsItem *item);
gboolean	e_ews_item_has_attachments	(EEwsItem *item,
						 gboolean *has_attachments);
gboolean	e_ews_item_is_read		(EEwsItem *item,
						 gboolean *is_read);
gboolean	e_ews_item_is_forwarded		(EEwsItem *item,
						 gboolean *is_forwarded);
gboolean	e_ews_item_is_answered		(EEwsItem *item,
						 gboolean *is_answered);
const GSList *	e_ews_item_get_to_recipients	(EEwsItem *item);
const GSList *	e_ews_item_get_cc_recipients	(EEwsItem *item);
const GSList *	e_ews_item_get_bcc_recipients	(EEwsItem *item);
const EwsMailbox *
		e_ews_item_get_sender		(EEwsItem *item);
const EwsMailbox *
		e_ews_item_get_from		(EEwsItem *item);
EwsImportance
		e_ews_item_get_importance	(EEwsItem *item);
const GSList *
		e_ews_item_get_categories	(EEwsItem *item);
EwsMailbox *
		e_ews_item_mailbox_from_soap_param
						(ESoapParameter *param);

const GSList *	e_ews_item_get_modified_occurrences
						(EEwsItem *item);
gchar *		e_ews_embed_attachment_id_in_uri (const gchar *olduri, const char *attach_id);
GSList *	e_ews_item_get_attachments_ids
						(EEwsItem *item);
gchar *
e_ews_dump_file_attachment_from_soap_parameter (ESoapParameter *param, const gchar *cache, const gchar *comp_uid, gchar **attach_id);

gchar *
e_ews_item_ical_dump(EEwsItem *item);

gchar *
e_ews_item_dump_mime_content(EEwsItem *item, const gchar *cache);

const GSList *	e_ews_item_get_attendees	(EEwsItem *item);

const EwsId *	e_ews_item_get_calendar_item_accept_id
						(EEwsItem *item);

/* Contact fields */
const gchar *	e_ews_item_get_fileas		(EEwsItem *item);
const EwsCompleteName *	
		e_ews_item_get_complete_name	(EEwsItem *item);
const gchar *	e_ews_item_get_email_address	(EEwsItem *item, const gchar *type);
const EwsAddress *	
		e_ews_item_get_physical_address	(EEwsItem *item, const gchar *type);
const gchar *	e_ews_item_get_phone_number	(EEwsItem *item, const gchar *type);
const gchar *	e_ews_item_get_im_address	(EEwsItem *item, const gchar *type);

const gchar *	e_ews_item_get_company_name	(EEwsItem *item);
const gchar *	e_ews_item_get_department	(EEwsItem *item);
const gchar *	e_ews_item_get_job_title	(EEwsItem *item);
const gchar *	e_ews_item_get_assistant_name	(EEwsItem *item);
const gchar *	e_ews_item_get_manager		(EEwsItem *item);
const gchar *	e_ews_item_get_office_location	(EEwsItem *item);
const gchar *	e_ews_item_get_business_homepage
						(EEwsItem *item);
time_t		e_ews_item_get_birthday		(EEwsItem *item);
time_t		e_ews_item_get_wedding_anniversary
						(EEwsItem *item);
const gchar *	e_ews_item_get_profession	(EEwsItem *item);
const gchar *	e_ews_item_get_spouse_name	(EEwsItem *item);
const gchar *	e_ews_item_get_culture		(EEwsItem *item);
const gchar *	e_ews_item_get_surname		(EEwsItem *item);

/*Task fields*/
const gchar *	e_ews_item_get_status		(EEwsItem *item);
const gchar *	e_ews_item_get_percent_complete (EEwsItem *item);
const gchar *	e_ews_item_get_sensitivity	(EEwsItem *item);
const gchar *	e_ews_item_get_body		(EEwsItem *item);
const gchar *	e_ews_item_get_owner		(EEwsItem *item);
const gchar *	e_ews_item_get_delegator	(EEwsItem *item);
time_t		e_ews_item_get_due_date		(EEwsItem *item);
time_t		e_ews_item_get_start_date	(EEwsItem *item);
time_t		e_ews_item_get_complete_date	(EEwsItem *item);
gboolean	e_ews_item_task_has_start_date	(EEwsItem *item,
						 gboolean *has_date);
gboolean	e_ews_item_task_has_due_date	(EEwsItem *item,
						 gboolean *has_date);
gboolean	e_ews_item_task_has_complete_date
						(EEwsItem* item,
						 gboolean* has_date);
const gchar *	e_ews_item_get_tzid		(EEwsItem *item);

G_END_DECLS

#endif
